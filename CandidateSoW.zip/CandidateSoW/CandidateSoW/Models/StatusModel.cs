﻿namespace CandidateSoW.Models
{
    public class StatusModel
    {
        public int StatusId { get; set; } = 0;
        public string StatusName { get; set; } = "";
        public string Type { get; set; } = "";

    }
}
