﻿namespace CandidateSoW.Models
{
    public class RecruiterModel
    {
        public int RecruiterId { get; set; }
        public string RecruiterName { get; set; } = "";

        public string Type { get; set; } = "";
    }
}
