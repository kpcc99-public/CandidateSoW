﻿namespace CandidateSoW.Models
{
    public class AccountModel
    {
        public int AccountId { get; set; } = 0;
        public string AccountName { get; set; } = "";
        public string Type { get; set; } = "";
    }
}
